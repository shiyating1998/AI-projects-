#!/bin/bash

#Run script for the huarong-pass puzzle
#one for puzzle1, and the other for puzzle2
#Assignment 1
#Artificial Intelligence (CS 486)
#
#Number of parameters: 1
#Parameter:
#    $1: <id> specify the file

python3 sol.py 1
python3 sol.py 2

