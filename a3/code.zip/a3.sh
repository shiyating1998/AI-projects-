
~


#!/bin/bash

#Run script for the Bayesian network
#Artificial Intelligence (CS 486)


python3 bayesian.py
